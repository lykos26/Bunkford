xbmc-decorator
==============

decorator packed for XBMC